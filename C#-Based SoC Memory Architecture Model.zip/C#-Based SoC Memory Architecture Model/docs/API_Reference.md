# API Reference

## Core Components

### MemorySystem

The main orchestrator for all memory components in the SoC.

```csharp
public class MemorySystem : IMemoryComponent
```

#### Properties
- `string Id` - Unique identifier for the memory system
- `string Name` - Human-readable name
- `ulong CurrentCycle` - Current simulation cycle
- `ulong TotalCycles` - Total cycles simulated
- `double PowerConsumption` - Current power consumption in watts
- `double Temperature` - Current temperature in Celsius
- `double Utilization` - Current utilization percentage

#### Methods
- `Task<MemoryResponse> ProcessRequestAsync(MemoryRequest request)` - Process a memory request
- `Task AdvanceCycleAsync()` - Advance simulation by one cycle
- `void AddComponent(IMemoryComponent component)` - Add a memory component
- `void RemoveComponent(string componentId)` - Remove a memory component
- `ComponentStatistics GetStatistics()` - Get performance statistics

### MemoryRequest

Represents a memory access request.

```csharp
public class MemoryRequest
```

#### Properties
- `Guid Id` - Unique request identifier
- `ulong Address` - Memory address
- `uint Size` - Request size in bytes
- `MemoryRequestType Type` - Type of request (Read, Write, etc.)
- `Priority Priority` - Request priority
- `string SourceId` - Source component ID
- `string TargetId` - Target component ID
- `byte[] Data` - Data for write requests
- `DateTime Timestamp` - Request timestamp
- `ulong IssueCycle` - Cycle when request was issued
- `ulong CompletionCycle` - Cycle when request completed
- `Dictionary<string, object> Metadata` - Additional metadata

#### Methods
- `TimeSpan GetLatency()` - Calculate request latency
- `MemoryResponse CreateResponse(MemoryResponseStatus status, byte[] data = null)` - Create response

### MemoryResponse

Represents a response to a memory request.

```csharp
public class MemoryResponse
```

#### Properties
- `Guid RequestId` - Original request ID
- `MemoryResponseStatus Status` - Response status
- `byte[] Data` - Response data
- `string ErrorMessage` - Error message if failed
- `ulong CompletionCycle` - Completion cycle
- `DateTime Timestamp` - Response timestamp
- `Dictionary<string, object> Metadata` - Additional metadata
- `bool IsSuccess` - Whether request was successful

#### Static Methods
- `MemoryResponse Success(Guid requestId, byte[] data, ulong completionCycle)` - Create success response
- `MemoryResponse Error(Guid requestId, MemoryResponseStatus status, string errorMessage)` - Create error response

## AXI Protocol

### AxiTransaction

Represents an AXI bus transaction.

```csharp
public class AxiTransaction
```

#### Properties
- `Guid Id` - Transaction ID
- `AxiProtocol Protocol` - AXI protocol version
- `AxiTransactionType TransactionType` - Transaction type
- `int MasterId` - Master ID
- `int SlaveId` - Slave ID
- `ulong Address` - Transaction address
- `AxiBurstType BurstType` - Burst type
- `int BurstLength` - Burst length
- `int BurstSize` - Burst size
- `int QoS` - Quality of Service level
- `int TransactionId` - AXI transaction ID
- `Dictionary<string, object> UserSignals` - User-defined signals
- `byte[] Data` - Transaction data
- `byte[] WriteStrobes` - Write strobes
- `AxiResponseStatus ResponseStatus` - Response status
- `ulong StartCycle` - Start cycle
- `ulong EndCycle` - End cycle
- `bool Cacheable` - Cacheable flag
- `bool Ordered` - Ordered flag
- `bool Exclusive` - Exclusive flag
- `bool Locked` - Locked flag

#### Methods
- `int GetTotalBytes()` - Calculate total bytes transferred
- `ulong GetLatency()` - Calculate transaction latency
- `ulong GetBeatAddress(int beatIndex)` - Get address for specific beat

## Cache Components

### CacheConfiguration

Configuration parameters for cache components.

```csharp
public class CacheConfiguration
```

#### Properties
- `int Size` - Cache size in bytes
- `int LineSize` - Cache line size in bytes
- `int Associativity` - Cache associativity
- `int Sets` - Number of cache sets
- `ReplacementPolicy ReplacementPolicy` - Replacement policy
- `WritePolicy WritePolicy` - Write policy
- `WriteAllocationPolicy WriteAllocationPolicy` - Write allocation policy
- `CoherencyProtocol CoherencyProtocol` - Cache coherency protocol
- `int HitLatency` - Hit latency in cycles
- `int MissLatency` - Miss latency in cycles
- `int ReadPorts` - Number of read ports
- `int WritePorts` - Number of write ports
- `int MSHREntries` - MSHR entries
- `int WriteBufferEntries` - Write buffer entries
- `PrefetchPolicy PrefetchPolicy` - Prefetch policy
- `int PrefetchDistance` - Prefetch distance
- `int PrefetchDegree` - Prefetch degree
- `double PowerPerAccess` - Power per access in watts
- `double StaticPower` - Static power in watts

#### Methods
- `bool Validate()` - Validate configuration
- `int GetCacheLineCount()` - Calculate number of cache lines
- `int GetTagBits()` - Calculate tag bits
- `int GetSetIndexBits()` - Calculate set index bits
- `int GetOffsetBits()` - Calculate offset bits

## DRAM Components

### DramConfiguration

Configuration for DRAM memory controllers.

```csharp
public class DramConfiguration
```

#### Properties
- `DramType Type` - DRAM type
- `int Capacity` - Memory capacity in bytes
- `int DataWidth` - Data bus width
- `int Channels` - Number of channels
- `int Ranks` - Number of ranks per channel
- `int Banks` - Number of banks per rank
- `int Rows` - Number of rows per bank
- `int Columns` - Number of columns per row
- `int CASLatency` - CAS latency
- `int RASLatency` - RAS latency
- `int PrechargeLatency` - Precharge latency
- `int RefreshInterval` - Refresh interval
- `double Frequency` - Memory frequency in MHz
- `double Voltage` - Operating voltage
- `double PowerPerAccess` - Power per access
- `double StaticPower` - Static power consumption

## Enums

### MemoryRequestType
- `Read` - Memory read request
- `Write` - Memory write request
- `ReadModifyWrite` - Atomic read-modify-write
- `Invalidate` - Cache invalidation
- `Flush` - Cache flush
- `Prefetch` - Data prefetch
- `MemoryBarrier` - Memory barrier
- `Snoop` - Cache snoop
- `Debug` - Debug access

### Priority
- `Low` - Low priority
- `Normal` - Normal priority
- `High` - High priority
- `Critical` - Critical priority
- `Emergency` - Emergency priority

### CacheState
- `Invalid` - Invalid state
- `Shared` - Shared state
- `Exclusive` - Exclusive state
- `Modified` - Modified state
- `Owned` - Owned state
- `Forward` - Forward state

### AxiProtocol
- `AXI3` - AXI3 protocol
- `AXI4` - AXI4 protocol
- `AXI4Lite` - AXI4-Lite protocol
- `AXI4Stream` - AXI4-Stream protocol
- `AXI5` - AXI5 protocol
- `AHB` - AHB protocol
- `APB` - APB protocol

### ReplacementPolicy
- `LRU` - Least Recently Used
- `PLRU` - Pseudo-LRU
- `FIFO` - First In First Out
- `Random` - Random replacement
- `LFU` - Least Frequently Used
- `Clock` - Clock algorithm
- `ARC` - Adaptive Replacement Cache
- `TwoQ` - 2Q algorithm

### CoherencyProtocol
- `MESI` - MESI protocol
- `MOESI` - MOESI protocol
- `MESIF` - MESIF protocol
- `MOESIF` - MOESIF protocol
- `Directory` - Directory-based coherency
- `Token` - Token-based coherency
- `None` - No coherency

### DramType
- `DDR3` - DDR3 SDRAM
- `DDR4` - DDR4 SDRAM
- `DDR5` - DDR5 SDRAM
- `LPDDR3` - LPDDR3 SDRAM
- `LPDDR4` - LPDDR4 SDRAM
- `LPDDR5` - LPDDR5 SDRAM
- `HBM` - High Bandwidth Memory
- `HBM2` - HBM2
- `HBM3` - HBM3
- `GDDR5` - GDDR5
- `GDDR6` - GDDR6
- `GDDR6X` - GDDR6X
- `GDDR7` - GDDR7

## Interfaces

### IMemoryComponent

Base interface for all memory components.

```csharp
public interface IMemoryComponent
```

#### Properties
- `string Id` - Component identifier
- `string Name` - Component name
- `ulong CurrentCycle` - Current cycle
- `ulong TotalCycles` - Total cycles
- `double PowerConsumption` - Power consumption
- `double Temperature` - Temperature
- `double Utilization` - Utilization

#### Methods
- `Task InitializeAsync()` - Initialize component
- `Task ResetAsync()` - Reset component
- `Task<MemoryResponse> ProcessRequestAsync(MemoryRequest request)` - Process request
- `Task AdvanceCycleAsync()` - Advance cycle
- `ComponentStatistics GetStatistics()` - Get statistics
- `bool ValidateConfiguration()` - Validate configuration

#### Events
- `event EventHandler<MemoryRequestEventArgs> RequestReceived` - Request received
- `event EventHandler<MemoryResponseEventArgs> ResponseGenerated` - Response generated
- `event EventHandler<MemoryErrorEventArgs> ErrorOccurred` - Error occurred

