# FPGA Prototyping Guide

## Overview

This guide covers FPGA prototyping and RTL generation capabilities of the C#-Based SoC Memory Architecture Model, including VHDL/Verilog generation, co-simulation, and hardware validation.

## RTL Generation

### VHDL Generation

The framework supports automatic generation of VHDL code for memory components.

```csharp
public class VhdlGenerator
{
    public static string GenerateCacheVhdl(CacheConfiguration config)
    {
        return $@"
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity cache_controller is
    Port (
        clk : in STD_LOGIC;
        rst : in STD_LOGIC;
        address : in STD_LOGIC_VECTOR(31 downto 0);
        data_in : in STD_LOGIC_VECTOR(63 downto 0);
        data_out : out STD_LOGIC_VECTOR(63 downto 0);
        read_en : in STD_LOGIC;
        write_en : in STD_LOGIC;
        hit : out STD_LOGIC;
        ready : out STD_LOGIC
    );
end cache_controller;

architecture Behavioral of cache_controller is
    -- Cache parameters
    constant CACHE_SIZE : integer := {config.Size};
    constant LINE_SIZE : integer := {config.LineSize};
    constant ASSOCIATIVITY : integer := {config.Associativity};
    constant SETS : integer := {config.Sets};
    
    -- Cache memory array
    type cache_line_t is record
        valid : STD_LOGIC;
        tag : STD_LOGIC_VECTOR(31 downto 0);
        data : STD_LOGIC_VECTOR(63 downto 0);
        lru : STD_LOGIC_VECTOR(7 downto 0);
    end record;
    
    type cache_set_t is array(0 to ASSOCIATIVITY-1) of cache_line_t;
    type cache_memory_t is array(0 to SETS-1) of cache_set_t;
    
    signal cache_memory : cache_memory_t;
    signal current_state : STD_LOGIC_VECTOR(2 downto 0);
    
begin
    -- Cache control logic
    process(clk, rst)
    begin
        if rst = '1' then
            current_state <= ""000"";
            hit <= '0';
            ready <= '0';
        elsif rising_edge(clk) then
            case current_state is
                when ""000"" => -- Idle
                    if read_en = '1' or write_en = '1' then
                        current_state <= ""001"";
                        ready <= '0';
                    end if;
                    
                when ""001"" => -- Tag comparison
                    -- Implement tag comparison logic
                    current_state <= ""010"";
                    
                when ""010"" => -- Hit/Miss determination
                    -- Implement hit/miss logic
                    if hit = '1' then
                        current_state <= ""011"";
                    else
                        current_state <= ""100"";
                    end if;
                    
                when ""011"" => -- Hit response
                    ready <= '1';
                    current_state <= ""000"";
                    
                when ""100"" => -- Miss handling
                    -- Implement miss handling
                    current_state <= ""000"";
                    
                when others =>
                    current_state <= ""000"";
            end case;
        end if;
    end process;
    
end Behavioral;";
    }
}
```

### Verilog Generation

```csharp
public class VerilogGenerator
{
    public static string GenerateAxiInterconnectVerilog(AxiConfiguration config)
    {
        return $@"
module axi_interconnect #(
    parameter DATA_WIDTH = {config.DataWidth},
    parameter ADDR_WIDTH = 32,
    parameter ID_WIDTH = 4,
    parameter MASTERS = {config.MasterCount},
    parameter SLAVES = {config.SlaveCount}
)(
    input wire clk,
    input wire rst_n,
    
    // Master interfaces
    input wire [MASTERS-1:0] m_axi_awvalid,
    output wire [MASTERS-1:0] m_axi_awready,
    input wire [MASTERS*ADDR_WIDTH-1:0] m_axi_awaddr,
    input wire [MASTERS*8-1:0] m_axi_awlen,
    input wire [MASTERS*3-1:0] m_axi_awsize,
    input wire [MASTERS*2-1:0] m_axi_awburst,
    input wire [MASTERS*ID_WIDTH-1:0] m_axi_awid,
    
    input wire [MASTERS-1:0] m_axi_wvalid,
    output wire [MASTERS-1:0] m_axi_wready,
    input wire [MASTERS*DATA_WIDTH-1:0] m_axi_wdata,
    input wire [MASTERS*DATA_WIDTH/8-1:0] m_axi_wstrb,
    input wire [MASTERS-1:0] m_axi_wlast,
    
    output wire [MASTERS-1:0] m_axi_bvalid,
    input wire [MASTERS-1:0] m_axi_bready,
    output wire [MASTERS*2-1:0] m_axi_bresp,
    output wire [MASTERS*ID_WIDTH-1:0] m_axi_bid,
    
    input wire [MASTERS-1:0] m_axi_arvalid,
    output wire [MASTERS-1:0] m_axi_arready,
    input wire [MASTERS*ADDR_WIDTH-1:0] m_axi_araddr,
    input wire [MASTERS*8-1:0] m_axi_arlen,
    input wire [MASTERS*3-1:0] m_axi_arsize,
    input wire [MASTERS*2-1:0] m_axi_arburst,
    input wire [MASTERS*ID_WIDTH-1:0] m_axi_arid,
    
    output wire [MASTERS-1:0] m_axi_rvalid,
    input wire [MASTERS-1:0] m_axi_rready,
    output wire [MASTERS*DATA_WIDTH-1:0] m_axi_rdata,
    output wire [MASTERS*2-1:0] m_axi_rresp,
    output wire [MASTERS-1:0] m_axi_rlast,
    output wire [MASTERS*ID_WIDTH-1:0] m_axi_rid,
    
    // Slave interfaces
    output wire [SLAVES-1:0] s_axi_awvalid,
    input wire [SLAVES-1:0] s_axi_awready,
    output wire [SLAVES*ADDR_WIDTH-1:0] s_axi_awaddr,
    output wire [SLAVES*8-1:0] s_axi_awlen,
    output wire [SLAVES*3-1:0] s_axi_awsize,
    output wire [SLAVES*2-1:0] s_axi_awburst,
    output wire [SLAVES*ID_WIDTH-1:0] s_axi_awid,
    
    output wire [SLAVES-1:0] s_axi_wvalid,
    input wire [SLAVES-1:0] s_axi_wready,
    output wire [SLAVES*DATA_WIDTH-1:0] s_axi_wdata,
    output wire [SLAVES*DATA_WIDTH/8-1:0] s_axi_wstrb,
    output wire [SLAVES-1:0] s_axi_wlast,
    
    input wire [SLAVES-1:0] s_axi_bvalid,
    output wire [SLAVES-1:0] s_axi_bready,
    input wire [SLAVES*2-1:0] s_axi_bresp,
    input wire [SLAVES*ID_WIDTH-1:0] s_axi_bid,
    
    output wire [SLAVES-1:0] s_axi_arvalid,
    input wire [SLAVES-1:0] s_axi_arready,
    output wire [SLAVES*ADDR_WIDTH-1:0] s_axi_araddr,
    output wire [SLAVES*8-1:0] s_axi_arlen,
    output wire [SLAVES*3-1:0] s_axi_arsize,
    output wire [SLAVES*2-1:0] s_axi_arburst,
    output wire [SLAVES*ID_WIDTH-1:0] s_axi_arid,
    
    input wire [SLAVES-1:0] s_axi_rvalid,
    output wire [SLAVES-1:0] s_axi_rready,
    input wire [SLAVES*DATA_WIDTH-1:0] s_axi_rdata,
    input wire [SLAVES*2-1:0] s_axi_rresp,
    input wire [SLAVES-1:0] s_axi_rlast,
    input wire [SLAVES*ID_WIDTH-1:0] s_axi_rid
);

    // Arbitration logic
    reg [MASTERS-1:0] aw_grant;
    reg [MASTERS-1:0] ar_grant;
    reg [MASTERS-1:0] w_grant;
    
    // Round-robin arbitration
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            aw_grant <= 0;
            ar_grant <= 0;
            w_grant <= 0;
        end else begin
            // Implement round-robin arbitration logic
        end
    end
    
    // Address decoding
    wire [SLAVES-1:0] aw_decode;
    wire [SLAVES-1:0] ar_decode;
    
    // Implement address decoding logic based on slave address ranges
    
    // Master to slave routing
    assign s_axi_awvalid = aw_grant & aw_decode;
    assign s_axi_arvalid = ar_grant & ar_decode;
    assign s_axi_wvalid = w_grant;
    
    // Slave to master routing
    assign m_axi_awready = |(s_axi_awready & aw_decode);
    assign m_axi_arready = |(s_axi_arready & ar_decode);
    assign m_axi_wready = |s_axi_wready;
    
endmodule";
    }
}
```

## Co-Simulation

### ModelSim Integration

```csharp
public class ModelSimCoSimulation
{
    private readonly string _modelsimPath;
    private readonly string _workDir;
    
    public ModelSimCoSimulation(string modelsimPath, string workDir)
    {
        _modelsimPath = modelsimPath;
        _workDir = workDir;
    }
    
    public async Task<bool> CompileVhdl(string vhdlFile)
    {
        var compileScript = $@"
vlib work
vmap work work
vcom -2008 ""{vhdlFile}""
quit -f";
        
        var scriptPath = Path.Combine(_workDir, "compile.do");
        await File.WriteAllTextAsync(scriptPath, compileScript);
        
        var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = _modelsimPath,
                Arguments = $"-c -do ""{scriptPath}""",
                WorkingDirectory = _workDir,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            }
        };
        
        process.Start();
        await process.WaitForExitAsync();
        
        return process.ExitCode == 0;
    }
    
    public async Task<bool> RunSimulation(string testbenchFile, ulong simulationCycles)
    {
        var simulationScript = $@"
vsim -c work.{Path.GetFileNameWithoutExtension(testbenchFile)}
run {simulationCycles}ns
quit -f";
        
        var scriptPath = Path.Combine(_workDir, "simulate.do");
        await File.WriteAllTextAsync(scriptPath, simulationScript);
        
        var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = _modelsimPath,
                Arguments = $"-c -do ""{scriptPath}""",
                WorkingDirectory = _workDir,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            }
        };
        
        process.Start();
        await process.WaitForExitAsync();
        
        return process.ExitCode == 0;
    }
}
```

### QuestaSim Integration

```csharp
public class QuestaSimCoSimulation
{
    private readonly string _questaPath;
    private readonly string _workDir;
    
    public QuestaSimCoSimulation(string questaPath, string workDir)
    {
        _questaPath = questaPath;
        _workDir = workDir;
    }
    
    public async Task<bool> CompileSystemVerilog(string svFile)
    {
        var compileScript = $@"
vlib work
vmap work work
vlog -sv ""{svFile}""
quit -f";
        
        var scriptPath = Path.Combine(_workDir, "compile.do");
        await File.WriteAllTextAsync(scriptPath, compileScript);
        
        var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = _questaPath,
                Arguments = $"-c -do ""{scriptPath}""",
                WorkingDirectory = _workDir,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            }
        };
        
        process.Start();
        await process.WaitForExitAsync();
        
        return process.ExitCode == 0;
    }
}
```

## Timing Analysis

### Static Timing Analysis

```csharp
public class TimingAnalyzer
{
    public class TimingConstraint
    {
        public string ClockName { get; set; }
        public double Frequency { get; set; }
        public double Period => 1.0 / Frequency;
        public string SourcePin { get; set; }
        public string DestinationPin { get; set; }
    }
    
    public class TimingReport
    {
        public double SetupSlack { get; set; }
        public double HoldSlack { get; set; }
        public double MaxDelay { get; set; }
        public double MinDelay { get; set; }
        public bool MeetsTiming { get; set; }
        public List<string> Violations { get; set; } = new();
    }
    
    public TimingReport AnalyzeTiming(List<TimingConstraint> constraints, string netlistFile)
    {
        var report = new TimingReport();
        
        // Parse netlist and calculate delays
        var delays = ParseNetlistDelays(netlistFile);
        
        foreach (var constraint in constraints)
        {
            var pathDelay = CalculatePathDelay(constraint.SourcePin, constraint.DestinationPin, delays);
            
            report.SetupSlack = constraint.Period - pathDelay;
            report.HoldSlack = pathDelay;
            
            if (report.SetupSlack < 0)
            {
                report.Violations.Add($"Setup violation: {constraint.SourcePin} -> {constraint.DestinationPin}");
                report.MeetsTiming = false;
            }
            
            if (report.HoldSlack < 0)
            {
                report.Violations.Add($"Hold violation: {constraint.SourcePin} -> {constraint.DestinationPin}");
                report.MeetsTiming = false;
            }
        }
        
        return report;
    }
    
    private Dictionary<string, double> ParseNetlistDelays(string netlistFile)
    {
        // Implement netlist parsing logic
        return new Dictionary<string, double>();
    }
    
    private double CalculatePathDelay(string source, string destination, Dictionary<string, double> delays)
    {
        // Implement path delay calculation
        return 0.0;
    }
}
```

## Resource Estimation

### FPGA Resource Estimation

```csharp
public class ResourceEstimator
{
    public class ResourceUsage
    {
        public int LUTs { get; set; }
        public int FFs { get; set; }
        public int BRAMs { get; set; }
        public int DSPs { get; set; }
        public double PowerEstimate { get; set; }
    }
    
    public ResourceUsage EstimateCacheResources(CacheConfiguration config)
    {
        var usage = new ResourceUsage();
        
        // Calculate LUTs for tag comparison
        var tagBits = config.GetTagBits();
        usage.LUTs += tagBits * config.Associativity;
        
        // Calculate BRAMs for cache storage
        var totalBits = config.Size * 8;
        var bramBits = 18432; // 18Kb BRAM
        usage.BRAMs = (int)Math.Ceiling((double)totalBits / bramBits);
        
        // Calculate FFs for control logic
        usage.FFs += config.Associativity * 32; // Tag storage
        usage.FFs += config.Sets * 8; // LRU counters
        
        // Estimate power
        usage.PowerEstimate = EstimatePower(usage);
        
        return usage;
    }
    
    public ResourceUsage EstimateAxiResources(AxiConfiguration config)
    {
        var usage = new ResourceUsage();
        
        // Arbitration logic
        usage.LUTs += config.MasterCount * config.SlaveCount * 4;
        
        // Address decoding
        usage.LUTs += config.SlaveCount * 32;
        
        // FIFOs for buffering
        var fifoDepth = 16;
        usage.FFs += config.MasterCount * fifoDepth * 64; // Data FIFOs
        usage.FFs += config.MasterCount * fifoDepth * 8;  // Control FIFOs
        
        // BRAMs for large FIFOs
        usage.BRAMs += config.MasterCount * 2; // Read/Write FIFOs
        
        usage.PowerEstimate = EstimatePower(usage);
        
        return usage;
    }
    
    private double EstimatePower(ResourceUsage usage)
    {
        // Power estimation model
        const double lutPower = 0.001; // W per LUT
        const double ffPower = 0.0005; // W per FF
        const double bramPower = 0.01; // W per BRAM
        const double dspPower = 0.1;   // W per DSP
        
        return usage.LUTs * lutPower + 
               usage.FFs * ffPower + 
               usage.BRAMs * bramPower + 
               usage.DSPs * dspPower;
    }
}
```

## Hardware Validation

### Testbench Generation

```csharp
public class TestbenchGenerator
{
    public static string GenerateCacheTestbench(CacheConfiguration config)
    {
        return $@"
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use IEEE.STD_LOGIC_TEXTIO.ALL;
use STD.TEXTIO.ALL;

entity cache_tb is
end cache_tb;

architecture Behavioral of cache_tb is
    component cache_controller is
        Port (
            clk : in STD_LOGIC;
            rst : in STD_LOGIC;
            address : in STD_LOGIC_VECTOR(31 downto 0);
            data_in : in STD_LOGIC_VECTOR(63 downto 0);
            data_out : out STD_LOGIC_VECTOR(63 downto 0);
            read_en : in STD_LOGIC;
            write_en : in STD_LOGIC;
            hit : out STD_LOGIC;
            ready : out STD_LOGIC
        );
    end component;
    
    signal clk : STD_LOGIC := '0';
    signal rst : STD_LOGIC := '1';
    signal address : STD_LOGIC_VECTOR(31 downto 0);
    signal data_in : STD_LOGIC_VECTOR(63 downto 0);
    signal data_out : STD_LOGIC_VECTOR(63 downto 0);
    signal read_en : STD_LOGIC := '0';
    signal write_en : STD_LOGIC := '0';
    signal hit : STD_LOGIC;
    signal ready : STD_LOGIC;
    
    constant CLK_PERIOD : time := 10 ns;
    
begin
    uut: cache_controller port map (
        clk => clk,
        rst => rst,
        address => address,
        data_in => data_in,
        data_out => data_out,
        read_en => read_en,
        write_en => write_en,
        hit => hit,
        ready => ready
    );
    
    -- Clock generation
    clk <= not clk after CLK_PERIOD/2;
    
    -- Stimulus process
    stim_proc: process
        variable line_var : line;
    begin
        -- Reset
        rst <= '1';
        wait for 100 ns;
        rst <= '0';
        wait for 10 ns;
        
        -- Test sequence
        -- Write test
        address <= X""00000000"";
        data_in <= X""123456789ABCDEF0"";
        write_en <= '1';
        wait until ready = '1';
        write_en <= '0';
        wait for 10 ns;
        
        -- Read test (should hit)
        address <= X""00000000"";
        read_en <= '1';
        wait until ready = '1';
        read_en <= '0';
        wait for 10 ns;
        
        -- Read test (should miss)
        address <= X""00000040"";
        read_en <= '1';
        wait until ready = '1';
        read_en <= '0';
        wait for 10 ns;
        
        -- End simulation
        wait for 1000 ns;
        std.env.stop;
    end process;
    
    -- Monitor process
    monitor_proc: process
        variable line_var : line;
    begin
        wait until rising_edge(clk);
        
        if read_en = '1' or write_en = '1' then
            write(line_var, ""Cycle: "" & integer'image(now / CLK_PERIOD));
            write(line_var, "" Address: "" & to_hstring(address));
            write(line_var, "" Hit: "" & std_logic'image(hit));
            write(line_var, "" Ready: "" & std_logic'image(ready));
            writeline(output, line_var);
        end if;
    end process;
    
end Behavioral;";
    }
}
```

## FPGA Implementation

### Xilinx Vivado Integration

```csharp
public class VivadoIntegration
{
    private readonly string _vivadoPath;
    private readonly string _projectDir;
    
    public VivadoIntegration(string vivadoPath, string projectDir)
    {
        _vivadoPath = vivadoPath;
        _projectDir = projectDir;
    }
    
    public async Task<bool> CreateProject(string projectName, List<string> sourceFiles)
    {
        var tclScript = $@"
create_project {projectName} {_projectDir} -part xc7k325tfbg676-2
set_property board_part digilentinc:arty-a7-35:part0:1.0 [current_project]

# Add source files
";
        
        foreach (var file in sourceFiles)
        {
            tclScript += $"add_files -norecurse {{{file}}}\n";
        }
        
        tclScript += @"
# Set top module
set_property top cache_controller [current_fileset]
set_property top_file ""cache_controller.vhd"" [current_fileset]

# Run synthesis
launch_runs synth_1
wait_on_run synth_1

# Run implementation
launch_runs impl_1 -to_step write_bitstream
wait_on_run impl_1

# Generate reports
open_run impl_1
report_timing_summary -file timing_report.txt
report_utilization -file utilization_report.txt
report_power -file power_report.txt

exit";
        
        var scriptPath = Path.Combine(_projectDir, "vivado_script.tcl");
        await File.WriteAllTextAsync(scriptPath, tclScript);
        
        var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = _vivadoPath,
                Arguments = $"-mode batch -source ""{scriptPath}""",
                WorkingDirectory = _projectDir,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            }
        };
        
        process.Start();
        await process.WaitForExitAsync();
        
        return process.ExitCode == 0;
    }
}
```

## Best Practices

1. **Modular Design**: Keep RTL modules small and focused
2. **Synchronous Design**: Use synchronous reset and avoid combinational loops
3. **Timing Constraints**: Define proper timing constraints early
4. **Resource Optimization**: Balance performance and resource usage
5. **Verification**: Use comprehensive testbenches and formal verification
6. **Documentation**: Document all interfaces and timing requirements

## Conclusion

The FPGA prototyping capabilities provide a complete workflow from C# model to hardware implementation, enabling rapid prototyping and validation of SoC memory architectures.

