namespace SoCMemoryArchitecture.Cache.Enums
{
    /// <summary>
    /// Defines cache coherency protocols for maintaining data consistency across multiple caches.
    /// </summary>
    public enum CoherencyProtocol
    {
        /// <summary>
        /// Modified, Exclusive, Shared, Invalid protocol
        /// </summary>
        MESI = 0,

        /// <summary>
        /// Modified, Owned, Exclusive, Shared, Invalid protocol
        /// </summary>
        MOESI = 1,

        /// <summary>
        /// Modified, Exclusive, Shared, Forward, Invalid protocol
        /// </summary>
        MESIF = 2,

        /// <summary>
        /// Modified, Owned, Exclusive, Shared, Forward, Invalid protocol
        /// </summary>
        MOESIF = 3,

        /// <summary>
        /// Directory-based coherency protocol
        /// </summary>
        Directory = 4,

        /// <summary>
        /// Token-based coherency protocol
        /// </summary>
        Token = 5,

        /// <summary>
        /// No coherency - each cache operates independently
        /// </summary>
        None = 6
    }
}

