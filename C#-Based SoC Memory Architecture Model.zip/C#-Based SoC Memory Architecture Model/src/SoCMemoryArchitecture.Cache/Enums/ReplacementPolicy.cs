namespace SoCMemoryArchitecture.Cache.Enums
{
    /// <summary>
    /// Defines cache line replacement policies for managing cache eviction.
    /// </summary>
    public enum ReplacementPolicy
    {
        /// <summary>
        /// Least Recently Used - evicts the least recently accessed cache line
        /// </summary>
        LRU = 0,

        /// <summary>
        /// Pseudo-LRU - approximation of LRU for better performance
        /// </summary>
        PLRU = 1,

        /// <summary>
        /// First In First Out - evicts the oldest cache line
        /// </summary>
        FIFO = 2,

        /// <summary>
        /// Random replacement - randomly selects a cache line for eviction
        /// </summary>
        Random = 3,

        /// <summary>
        /// Least Frequently Used - evicts the least frequently accessed cache line
        /// </summary>
        LFU = 4,

        /// <summary>
        /// Clock replacement - circular buffer with reference bit
        /// </summary>
        Clock = 5,

        /// <summary>
        /// Adaptive Replacement Cache - adapts between LRU and LFU
        /// </summary>
        ARC = 6,

        /// <summary>
        /// 2Q replacement - two-level queue replacement policy
        /// </summary>
        TwoQ = 7
    }
}

