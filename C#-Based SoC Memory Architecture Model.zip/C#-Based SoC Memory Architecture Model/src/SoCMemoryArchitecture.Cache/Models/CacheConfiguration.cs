using SoCMemoryArchitecture.Cache.Enums;

namespace SoCMemoryArchitecture.Cache.Models
{
    /// <summary>
    /// Defines the configuration parameters for a cache memory component.
    /// </summary>
    public class CacheConfiguration
    {
        /// <summary>
        /// Total cache size in bytes
        /// </summary>
        public ulong Size { get; set; }

        /// <summary>
        /// Cache line size in bytes
        /// </summary>
        public uint LineSize { get; set; }

        /// <summary>
        /// Cache associativity (number of ways)
        /// </summary>
        public uint Associativity { get; set; }

        /// <summary>
        /// Number of sets in the cache
        /// </summary>
        public uint Sets { get; set; }

        /// <summary>
        /// Replacement policy for cache line eviction
        /// </summary>
        public ReplacementPolicy ReplacementPolicy { get; set; }

        /// <summary>
        /// Write policy (write-through or write-back)
        /// </summary>
        public WritePolicy WritePolicy { get; set; }

        /// <summary>
        /// Write allocation policy
        /// </summary>
        public WriteAllocationPolicy WriteAllocationPolicy { get; set; }

        /// <summary>
        /// Cache coherency protocol
        /// </summary>
        public CoherencyProtocol CoherencyProtocol { get; set; }

        /// <summary>
        /// Latency for cache hit in cycles
        /// </summary>
        public uint HitLatency { get; set; }

        /// <summary>
        /// Latency for cache miss in cycles
        /// </summary>
        public uint MissLatency { get; set; }

        /// <summary>
        /// Number of read ports
        /// </summary>
        public uint ReadPorts { get; set; }

        /// <summary>
        /// Number of write ports
        /// </summary>
        public uint WritePorts { get; set; }

        /// <summary>
        /// Number of MSHR (Miss Status Holding Register) entries
        /// </summary>
        public uint MSHREntries { get; set; }

        /// <summary>
        /// Number of write buffer entries
        /// </summary>
        public uint WriteBufferEntries { get; set; }

        /// <summary>
        /// Prefetch policy
        /// </summary>
        public PrefetchPolicy PrefetchPolicy { get; set; }

        /// <summary>
        /// Prefetch distance (number of cache lines ahead)
        /// </summary>
        public uint PrefetchDistance { get; set; }

        /// <summary>
        /// Prefetch degree (number of cache lines to prefetch)
        /// </summary>
        public uint PrefetchDegree { get; set; }

        /// <summary>
        /// Power consumption in milliwatts per access
        /// </summary>
        public double PowerPerAccess { get; set; }

        /// <summary>
        /// Static power consumption in milliwatts
        /// </summary>
        public double StaticPower { get; set; }

        /// <summary>
        /// Initializes a new instance of the CacheConfiguration class with default values.
        /// </summary>
        public CacheConfiguration()
        {
            Size = 32 * 1024; // 32KB default
            LineSize = 64; // 64-byte cache lines
            Associativity = 4; // 4-way set associative
            ReplacementPolicy = ReplacementPolicy.LRU;
            WritePolicy = WritePolicy.WriteBack;
            WriteAllocationPolicy = WriteAllocationPolicy.WriteAllocate;
            CoherencyProtocol = CoherencyProtocol.MESI;
            HitLatency = 1; // 1 cycle hit latency
            MissLatency = 10; // 10 cycle miss latency
            ReadPorts = 1;
            WritePorts = 1;
            MSHREntries = 8;
            WriteBufferEntries = 4;
            PrefetchPolicy = PrefetchPolicy.None;
            PrefetchDistance = 1;
            PrefetchDegree = 1;
            PowerPerAccess = 1.0; // 1 mW per access
            StaticPower = 10.0; // 10 mW static power

            // Calculate number of sets based on size, line size, and associativity
            Sets = (uint)(Size / (LineSize * Associativity));
        }

        /// <summary>
        /// Initializes a new instance of the CacheConfiguration class with specified parameters.
        /// </summary>
        /// <param name="size">Cache size in bytes</param>
        /// <param name="lineSize">Cache line size in bytes</param>
        /// <param name="associativity">Cache associativity</param>
        public CacheConfiguration(ulong size, uint lineSize, uint associativity)
            : this()
        {
            Size = size;
            LineSize = lineSize;
            Associativity = associativity;
            Sets = (uint)(Size / (LineSize * Associativity));
        }

        /// <summary>
        /// Validates the cache configuration parameters.
        /// </summary>
        /// <returns>True if the configuration is valid, false otherwise</returns>
        public bool Validate()
        {
            // Check basic constraints
            if (Size == 0 || LineSize == 0 || Associativity == 0)
                return false;

            if (Size % (LineSize * Associativity) != 0)
                return false;

            if (Sets == 0)
                return false;

            // Check power values
            if (PowerPerAccess < 0 || StaticPower < 0)
                return false;

            // Check latency values
            if (HitLatency == 0 || MissLatency == 0)
                return false;

            // Check port counts
            if (ReadPorts == 0 || WritePorts == 0)
                return false;

            return true;
        }

        /// <summary>
        /// Gets the total number of cache lines in the cache.
        /// </summary>
        /// <returns>Number of cache lines</returns>
        public uint GetCacheLineCount()
        {
            return (uint)(Size / LineSize);
        }

        /// <summary>
        /// Gets the number of bits needed for the tag field.
        /// </summary>
        /// <param name="addressWidth">Width of the address bus in bits</param>
        /// <returns>Number of tag bits</returns>
        public uint GetTagBits(uint addressWidth)
        {
            var setBits = (uint)System.Math.Log2(Sets);
            var offsetBits = (uint)System.Math.Log2(LineSize);
            return addressWidth - setBits - offsetBits;
        }

        /// <summary>
        /// Gets the number of bits needed for the set index.
        /// </summary>
        /// <returns>Number of set index bits</returns>
        public uint GetSetIndexBits()
        {
            return (uint)System.Math.Log2(Sets);
        }

        /// <summary>
        /// Gets the number of bits needed for the byte offset within a cache line.
        /// </summary>
        /// <returns>Number of offset bits</returns>
        public uint GetOffsetBits()
        {
            return (uint)System.Math.Log2(LineSize);
        }

        /// <summary>
        /// Returns a string representation of the cache configuration.
        /// </summary>
        /// <returns>String representation</returns>
        public override string ToString()
        {
            return $"CacheConfig[Size={Size}, LineSize={LineSize}, Ways={Associativity}, Sets={Sets}, Policy={ReplacementPolicy}]";
        }
    }

    /// <summary>
    /// Defines the write policy for cache operations.
    /// </summary>
    public enum WritePolicy
    {
        /// <summary>
        /// Write-through - writes go directly to memory
        /// </summary>
        WriteThrough = 0,

        /// <summary>
        /// Write-back - writes are buffered in cache
        /// </summary>
        WriteBack = 1
    }

    /// <summary>
    /// Defines the write allocation policy for cache misses.
    /// </summary>
    public enum WriteAllocationPolicy
    {
        /// <summary>
        /// No write allocation - write misses don't allocate cache lines
        /// </summary>
        NoWriteAllocate = 0,

        /// <summary>
        /// Write allocate - write misses allocate cache lines
        /// </summary>
        WriteAllocate = 1
    }

    /// <summary>
    /// Defines the prefetch policy for cache optimization.
    /// </summary>
    public enum PrefetchPolicy
    {
        /// <summary>
        /// No prefetching
        /// </summary>
        None = 0,

        /// <summary>
        /// Sequential prefetching
        /// </summary>
        Sequential = 1,

        /// <summary>
        /// Stride-based prefetching
        /// </summary>
        Stride = 2,

        /// <summary>
        /// Pattern-based prefetching
        /// </summary>
        Pattern = 3,

        /// <summary>
        /// Adaptive prefetching
        /// </summary>
        Adaptive = 4
    }
}

