namespace SoCMemoryArchitecture.DRAM.Enums
{
    /// <summary>
    /// Defines the different DRAM types and standards supported by the system.
    /// </summary>
    public enum DramType
    {
        /// <summary>
        /// DDR3 SDRAM
        /// </summary>
        DDR3 = 0,

        /// <summary>
        /// DDR4 SDRAM
        /// </summary>
        DDR4 = 1,

        /// <summary>
        /// DDR5 SDRAM
        /// </summary>
        DDR5 = 2,

        /// <summary>
        /// LPDDR3 (Low Power DDR3)
        /// </summary>
        LPDDR3 = 3,

        /// <summary>
        /// LPDDR4 (Low Power DDR4)
        /// </summary>
        LPDDR4 = 4,

        /// <summary>
        /// LPDDR5 (Low Power DDR5)
        /// </summary>
        LPDDR5 = 5,

        /// <summary>
        /// HBM (High Bandwidth Memory)
        /// </summary>
        HBM = 6,

        /// <summary>
        /// HBM2 (High Bandwidth Memory 2)
        /// </summary>
        HBM2 = 7,

        /// <summary>
        /// HBM3 (High Bandwidth Memory 3)
        /// </summary>
        HBM3 = 8,

        /// <summary>
        /// GDDR5 (Graphics DDR5)
        /// </summary>
        GDDR5 = 9,

        /// <summary>
        /// GDDR6 (Graphics DDR6)
        /// </summary>
        GDDR6 = 10,

        /// <summary>
        /// GDDR6X (Graphics DDR6X)
        /// </summary>
        GDDR6X = 11,

        /// <summary>
        /// GDDR7 (Graphics DDR7)
        /// </summary>
        GDDR7 = 12
    }
}

