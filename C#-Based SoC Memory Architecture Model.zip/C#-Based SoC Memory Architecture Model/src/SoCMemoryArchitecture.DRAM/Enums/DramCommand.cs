namespace SoCMemoryArchitecture.DRAM.Enums
{
    /// <summary>
    /// Defines the different DRAM commands that can be issued to the memory controller.
    /// </summary>
    public enum DramCommand
    {
        /// <summary>
        /// No operation
        /// </summary>
        NOP = 0,

        /// <summary>
        /// Activate command - opens a row
        /// </summary>
        ACT = 1,

        /// <summary>
        /// Read command
        /// </summary>
        READ = 2,

        /// <summary>
        /// Write command
        /// </summary>
        WRITE = 3,

        /// <summary>
        /// Precharge command - closes a row
        /// </summary>
        PRE = 4,

        /// <summary>
        /// Precharge all banks
        /// </summary>
        PREA = 5,

        /// <summary>
        /// Refresh command
        /// </summary>
        REF = 6,

        /// <summary>
        /// Self-refresh entry
        /// </summary>
        SRE = 7,

        /// <summary>
        /// Self-refresh exit
        /// </summary>
        SRX = 8,

        /// <summary>
        /// Power-down entry
        /// </summary>
        PDE = 9,

        /// <summary>
        /// Power-down exit
        /// </summary>
        PDX = 10,

        /// <summary>
        /// Mode register set
        /// </summary>
        MRS = 11,

        /// <summary>
        /// Mode register read
        /// </summary>
        MRR = 12,

        /// <summary>
        /// ZQ calibration
        /// </summary>
        ZQC = 13,

        /// <summary>
        /// Auto-refresh
        /// </summary>
        ARF = 14,

        /// <summary>
        /// Write with auto-precharge
        /// </summary>
        WRA = 15,

        /// <summary>
        /// Read with auto-precharge
        /// </summary>
        RDA = 16
    }
}

