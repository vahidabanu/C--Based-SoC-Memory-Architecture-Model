using System;
using System.Threading.Tasks;
using SoCMemoryArchitecture.Core.Models;

namespace SoCMemoryArchitecture.Core.Interfaces
{
    /// <summary>
    /// Defines the core interface for all memory components in the SoC memory system.
    /// </summary>
    public interface IMemoryComponent : IDisposable
    {
        /// <summary>
        /// Gets the unique identifier for this memory component.
        /// </summary>
        string Id { get; }

        /// <summary>
        /// Gets the name of this memory component.
        /// </summary>
        string Name { get; }

        /// <summary>
        /// Gets the current cycle count of this component.
        /// </summary>
        ulong CurrentCycle { get; }

        /// <summary>
        /// Gets the total number of cycles this component has been active.
        /// </summary>
        ulong TotalCycles { get; }

        /// <summary>
        /// Gets the current power consumption of this component in milliwatts.
        /// </summary>
        double PowerConsumption { get; }

        /// <summary>
        /// Gets the current temperature of this component in degrees Celsius.
        /// </summary>
        double Temperature { get; }

        /// <summary>
        /// Gets the utilization percentage of this component (0-100).
        /// </summary>
        double Utilization { get; }

        /// <summary>
        /// Initializes the memory component.
        /// </summary>
        /// <returns>Task representing the initialization operation</returns>
        Task InitializeAsync();

        /// <summary>
        /// Resets the memory component to its initial state.
        /// </summary>
        /// <returns>Task representing the reset operation</returns>
        Task ResetAsync();

        /// <summary>
        /// Processes a memory request.
        /// </summary>
        /// <param name="request">The memory request to process</param>
        /// <returns>Task containing the memory response</returns>
        Task<MemoryResponse> ProcessRequestAsync(MemoryRequest request);

        /// <summary>
        /// Advances the component by one cycle.
        /// </summary>
        /// <returns>Task representing the cycle advancement</returns>
        Task AdvanceCycleAsync();

        /// <summary>
        /// Gets statistics about this memory component.
        /// </summary>
        /// <returns>Component statistics</returns>
        ComponentStatistics GetStatistics();

        /// <summary>
        /// Validates the configuration of this memory component.
        /// </summary>
        /// <returns>True if the configuration is valid, false otherwise</returns>
        bool ValidateConfiguration();

        /// <summary>
        /// Event raised when a memory request is received.
        /// </summary>
        event EventHandler<MemoryRequestEventArgs> RequestReceived;

        /// <summary>
        /// Event raised when a memory response is generated.
        /// </summary>
        event EventHandler<MemoryResponseEventArgs> ResponseGenerated;

        /// <summary>
        /// Event raised when an error occurs in the component.
        /// </summary>
        event EventHandler<MemoryErrorEventArgs> ErrorOccurred;
    }

    /// <summary>
    /// Event arguments for memory request events.
    /// </summary>
    public class MemoryRequestEventArgs : EventArgs
    {
        /// <summary>
        /// The memory request that was received.
        /// </summary>
        public MemoryRequest Request { get; set; }

        /// <summary>
        /// The cycle when the request was received.
        /// </summary>
        public ulong Cycle { get; set; }

        public MemoryRequestEventArgs(MemoryRequest request, ulong cycle)
        {
            Request = request;
            Cycle = cycle;
        }
    }

    /// <summary>
    /// Event arguments for memory response events.
    /// </summary>
    public class MemoryResponseEventArgs : EventArgs
    {
        /// <summary>
        /// The memory response that was generated.
        /// </summary>
        public MemoryResponse Response { get; set; }

        /// <summary>
        /// The cycle when the response was generated.
        /// </summary>
        public ulong Cycle { get; set; }

        public MemoryResponseEventArgs(MemoryResponse response, ulong cycle)
        {
            Response = response;
            Cycle = cycle;
        }
    }

    /// <summary>
    /// Event arguments for memory error events.
    /// </summary>
    public class MemoryErrorEventArgs : EventArgs
    {
        /// <summary>
        /// The error message.
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// The exception that caused the error.
        /// </summary>
        public Exception Exception { get; set; }

        /// <summary>
        /// The cycle when the error occurred.
        /// </summary>
        public ulong Cycle { get; set; }

        public MemoryErrorEventArgs(string errorMessage, Exception exception, ulong cycle)
        {
            ErrorMessage = errorMessage;
            Exception = exception;
            Cycle = cycle;
        }
    }

    /// <summary>
    /// Represents statistics for a memory component.
    /// </summary>
    public class ComponentStatistics
    {
        /// <summary>
        /// Total number of requests processed.
        /// </summary>
        public ulong TotalRequests { get; set; }

        /// <summary>
        /// Total number of successful requests.
        /// </summary>
        public ulong SuccessfulRequests { get; set; }

        /// <summary>
        /// Total number of failed requests.
        /// </summary>
        public ulong FailedRequests { get; set; }

        /// <summary>
        /// Average latency in cycles.
        /// </summary>
        public double AverageLatency { get; set; }

        /// <summary>
        /// Maximum latency in cycles.
        /// </summary>
        public ulong MaximumLatency { get; set; }

        /// <summary>
        /// Minimum latency in cycles.
        /// </summary>
        public ulong MinimumLatency { get; set; }

        /// <summary>
        /// Total power consumed in milliwatt-hours.
        /// </summary>
        public double TotalPowerConsumption { get; set; }

        /// <summary>
        /// Peak power consumption in milliwatts.
        /// </summary>
        public double PeakPowerConsumption { get; set; }

        /// <summary>
        /// Gets the success rate as a percentage.
        /// </summary>
        public double SuccessRate => TotalRequests > 0 ? (double)SuccessfulRequests / TotalRequests * 100.0 : 0.0;

        /// <summary>
        /// Gets the failure rate as a percentage.
        /// </summary>
        public double FailureRate => TotalRequests > 0 ? (double)FailedRequests / TotalRequests * 100.0 : 0.0;
    }
}

