using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SoCMemoryArchitecture.Core.Interfaces;
using SoCMemoryArchitecture.Core.Models;

namespace SoCMemoryArchitecture.Core.Models
{
    /// <summary>
    /// Represents the complete SoC memory system that orchestrates all memory components.
    /// </summary>
    public class MemorySystem : IMemoryComponent
    {
        private readonly ILogger<MemorySystem> _logger;
        private readonly List<IMemoryComponent> _components;
        private readonly Dictionary<string, IMemoryComponent> _componentMap;
        private readonly Queue<MemoryRequest> _requestQueue;
        private readonly List<MemoryResponse> _responseHistory;
        private readonly object _lockObject;

        /// <summary>
        /// Gets the unique identifier for this memory system.
        /// </summary>
        public string Id { get; }

        /// <summary>
        /// Gets the name of this memory system.
        /// </summary>
        public string Name { get; }

        /// <summary>
        /// Gets the current cycle count of this memory system.
        /// </summary>
        public ulong CurrentCycle { get; private set; }

        /// <summary>
        /// Gets the total number of cycles this memory system has been active.
        /// </summary>
        public ulong TotalCycles { get; private set; }

        /// <summary>
        /// Gets the current power consumption of this memory system in milliwatts.
        /// </summary>
        public double PowerConsumption => _components.Sum(c => c.PowerConsumption);

        /// <summary>
        /// Gets the current temperature of this memory system in degrees Celsius.
        /// </summary>
        public double Temperature => _components.Any() ? _components.Average(c => c.Temperature) : 0.0;

        /// <summary>
        /// Gets the utilization percentage of this memory system (0-100).
        /// </summary>
        public double Utilization => _components.Any() ? _components.Average(c => c.Utilization) : 0.0;

        /// <summary>
        /// Gets the number of pending requests in the queue.
        /// </summary>
        public int PendingRequestCount => _requestQueue.Count;

        /// <summary>
        /// Gets the total number of requests processed by this memory system.
        /// </summary>
        public ulong TotalRequestsProcessed { get; private set; }

        /// <summary>
        /// Gets the total number of successful requests.
        /// </summary>
        public ulong TotalSuccessfulRequests { get; private set; }

        /// <summary>
        /// Gets the total number of failed requests.
        /// </summary>
        public ulong TotalFailedRequests { get; private set; }

        /// <summary>
        /// Event raised when a memory request is received.
        /// </summary>
        public event EventHandler<MemoryRequestEventArgs> RequestReceived;

        /// <summary>
        /// Event raised when a memory response is generated.
        /// </summary>
        public event EventHandler<MemoryResponseEventArgs> ResponseGenerated;

        /// <summary>
        /// Event raised when an error occurs in the memory system.
        /// </summary>
        public event EventHandler<MemoryErrorEventArgs> ErrorOccurred;

        /// <summary>
        /// Initializes a new instance of the MemorySystem class.
        /// </summary>
        /// <param name="name">Name of the memory system</param>
        /// <param name="logger">Logger instance</param>
        public MemorySystem(string name = "SoC Memory System", ILogger<MemorySystem> logger = null)
        {
            Id = Guid.NewGuid().ToString();
            Name = name;
            _logger = logger;
            _components = new List<IMemoryComponent>();
            _componentMap = new Dictionary<string, IMemoryComponent>();
            _requestQueue = new Queue<MemoryRequest>();
            _responseHistory = new List<MemoryResponse>();
            _lockObject = new object();

            _logger?.LogInformation("Memory system '{Name}' initialized with ID {Id}", Name, Id);
        }

        /// <summary>
        /// Adds a memory component to the system.
        /// </summary>
        /// <param name="component">The memory component to add</param>
        public void AddComponent(IMemoryComponent component)
        {
            if (component == null)
                throw new ArgumentNullException(nameof(component));

            lock (_lockObject)
            {
                if (_componentMap.ContainsKey(component.Id))
                {
                    throw new InvalidOperationException($"Component with ID '{component.Id}' already exists in the memory system.");
                }

                _components.Add(component);
                _componentMap[component.Id] = component;

                // Subscribe to component events
                component.RequestReceived += OnComponentRequestReceived;
                component.ResponseGenerated += OnComponentResponseGenerated;
                component.ErrorOccurred += OnComponentErrorOccurred;

                _logger?.LogInformation("Added component '{ComponentName}' (ID: {ComponentId}) to memory system", 
                    component.Name, component.Id);
            }
        }

        /// <summary>
        /// Removes a memory component from the system.
        /// </summary>
        /// <param name="componentId">The ID of the component to remove</param>
        /// <returns>True if the component was removed, false otherwise</returns>
        public bool RemoveComponent(string componentId)
        {
            if (string.IsNullOrEmpty(componentId))
                throw new ArgumentException("Component ID cannot be null or empty.", nameof(componentId));

            lock (_lockObject)
            {
                if (!_componentMap.TryGetValue(componentId, out var component))
                {
                    return false;
                }

                // Unsubscribe from component events
                component.RequestReceived -= OnComponentRequestReceived;
                component.ResponseGenerated -= OnComponentResponseGenerated;
                component.ErrorOccurred -= OnComponentErrorOccurred;

                _components.Remove(component);
                _componentMap.Remove(componentId);

                _logger?.LogInformation("Removed component '{ComponentName}' (ID: {ComponentId}) from memory system", 
                    component.Name, componentId);

                return true;
            }
        }

        /// <summary>
        /// Gets a memory component by its ID.
        /// </summary>
        /// <param name="componentId">The ID of the component to retrieve</param>
        /// <returns>The memory component, or null if not found</returns>
        public IMemoryComponent GetComponent(string componentId)
        {
            if (string.IsNullOrEmpty(componentId))
                throw new ArgumentException("Component ID cannot be null or empty.", nameof(componentId));

            lock (_lockObject)
            {
                return _componentMap.TryGetValue(componentId, out var component) ? component : null;
            }
        }

        /// <summary>
        /// Gets all memory components in the system.
        /// </summary>
        /// <returns>Collection of memory components</returns>
        public IReadOnlyList<IMemoryComponent> GetComponents()
        {
            lock (_lockObject)
            {
                return _components.ToList().AsReadOnly();
            }
        }

        /// <summary>
        /// Initializes the memory system and all its components.
        /// </summary>
        /// <returns>Task representing the initialization operation</returns>
        public async Task InitializeAsync()
        {
            _logger?.LogInformation("Initializing memory system '{Name}'", Name);

            try
            {
                var initializationTasks = _components.Select(c => c.InitializeAsync());
                await Task.WhenAll(initializationTasks);

                _logger?.LogInformation("Memory system '{Name}' initialized successfully", Name);
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Failed to initialize memory system '{Name}'", Name);
                throw;
            }
        }

        /// <summary>
        /// Resets the memory system and all its components.
        /// </summary>
        /// <returns>Task representing the reset operation</returns>
        public async Task ResetAsync()
        {
            _logger?.LogInformation("Resetting memory system '{Name}'", Name);

            try
            {
                lock (_lockObject)
                {
                    _requestQueue.Clear();
                    _responseHistory.Clear();
                    CurrentCycle = 0;
                    TotalCycles = 0;
                    TotalRequestsProcessed = 0;
                    TotalSuccessfulRequests = 0;
                    TotalFailedRequests = 0;
                }

                var resetTasks = _components.Select(c => c.ResetAsync());
                await Task.WhenAll(resetTasks);

                _logger?.LogInformation("Memory system '{Name}' reset successfully", Name);
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Failed to reset memory system '{Name}'", Name);
                throw;
            }
        }

        /// <summary>
        /// Processes a memory request through the memory system.
        /// </summary>
        /// <param name="request">The memory request to process</param>
        /// <returns>Task containing the memory response</returns>
        public async Task<MemoryResponse> ProcessRequestAsync(MemoryRequest request)
        {
            if (request == null)
                throw new ArgumentNullException(nameof(request));

            request.IssueCycle = CurrentCycle;
            TotalRequestsProcessed++;

            _logger?.LogDebug("Processing memory request {RequestId} at cycle {Cycle}", 
                request.Id, CurrentCycle);

            try
            {
                // Find the appropriate component to handle this request
                var targetComponent = FindTargetComponent(request);
                if (targetComponent == null)
                {
                    var errorResponse = MemoryResponse.Error(request.Id, 
                        MemoryResponseStatus.ResourceUnavailable, 
                        "No suitable component found to handle the request");
                    
                    TotalFailedRequests++;
                    return errorResponse;
                }

                // Process the request through the target component
                var response = await targetComponent.ProcessRequestAsync(request);
                
                if (response.IsSuccess)
                {
                    TotalSuccessfulRequests++;
                }
                else
                {
                    TotalFailedRequests++;
                }

                // Store the response in history
                lock (_lockObject)
                {
                    _responseHistory.Add(response);
                }

                _logger?.LogDebug("Memory request {RequestId} completed with status {Status}", 
                    request.Id, response.Status);

                return response;
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Error processing memory request {RequestId}", request.Id);
                
                TotalFailedRequests++;
                var errorResponse = MemoryResponse.Error(request.Id, 
                    MemoryResponseStatus.UnknownError, 
                    ex.Message);
                
                OnErrorOccurred($"Error processing memory request {request.Id}", ex);
                return errorResponse;
            }
        }

        /// <summary>
        /// Advances the memory system by one cycle.
        /// </summary>
        /// <returns>Task representing the cycle advancement</returns>
        public async Task AdvanceCycleAsync()
        {
            try
            {
                // Advance all components
                var advanceTasks = _components.Select(c => c.AdvanceCycleAsync());
                await Task.WhenAll(advanceTasks);

                // Process any pending requests in the queue
                await ProcessPendingRequests();

                CurrentCycle++;
                TotalCycles++;

                _logger?.LogTrace("Memory system advanced to cycle {Cycle}", CurrentCycle);
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Error advancing memory system cycle");
                OnErrorOccurred("Error advancing memory system cycle", ex);
                throw;
            }
        }

        /// <summary>
        /// Gets comprehensive statistics about the memory system.
        /// </summary>
        /// <returns>Memory system statistics</returns>
        public ComponentStatistics GetStatistics()
        {
            var componentStats = _components.Select(c => c.GetStatistics()).ToList();

            return new ComponentStatistics
            {
                TotalRequests = TotalRequestsProcessed,
                SuccessfulRequests = TotalSuccessfulRequests,
                FailedRequests = TotalFailedRequests,
                AverageLatency = componentStats.Any() ? componentStats.Average(s => s.AverageLatency) : 0.0,
                MaximumLatency = componentStats.Any() ? componentStats.Max(s => s.MaximumLatency) : 0,
                MinimumLatency = componentStats.Any() ? componentStats.Min(s => s.MinimumLatency) : 0,
                TotalPowerConsumption = componentStats.Sum(s => s.TotalPowerConsumption),
                PeakPowerConsumption = componentStats.Any() ? componentStats.Max(s => s.PeakPowerConsumption) : 0.0
            };
        }

        /// <summary>
        /// Validates the configuration of the memory system.
        /// </summary>
        /// <returns>True if the configuration is valid, false otherwise</returns>
        public bool ValidateConfiguration()
        {
            return _components.All(c => c.ValidateConfiguration());
        }

        /// <summary>
        /// Disposes the memory system and all its components.
        /// </summary>
        public void Dispose()
        {
            _logger?.LogInformation("Disposing memory system '{Name}'", Name);

            lock (_lockObject)
            {
                foreach (var component in _components)
                {
                    try
                    {
                        component.Dispose();
                    }
                    catch (Exception ex)
                    {
                        _logger?.LogError(ex, "Error disposing component '{ComponentName}'", component.Name);
                    }
                }

                _components.Clear();
                _componentMap.Clear();
                _requestQueue.Clear();
                _responseHistory.Clear();
            }

            _logger?.LogInformation("Memory system '{Name}' disposed", Name);
        }

        /// <summary>
        /// Finds the appropriate component to handle a memory request.
        /// </summary>
        /// <param name="request">The memory request</param>
        /// <returns>The target component, or null if none found</returns>
        private IMemoryComponent FindTargetComponent(MemoryRequest request)
        {
            // This is a simplified implementation. In a real system, this would use
            // address mapping, routing tables, or other logic to determine the target component.
            
            // For now, return the first available component that can handle the request
            return _components.FirstOrDefault();
        }

        /// <summary>
        /// Processes any pending requests in the queue.
        /// </summary>
        /// <returns>Task representing the processing operation</returns>
        private async Task ProcessPendingRequests()
        {
            var requestsToProcess = new List<MemoryRequest>();

            lock (_lockObject)
            {
                while (_requestQueue.Count > 0)
                {
                    requestsToProcess.Add(_requestQueue.Dequeue());
                }
            }

            foreach (var request in requestsToProcess)
            {
                await ProcessRequestAsync(request);
            }
        }

        /// <summary>
        /// Handles component request received events.
        /// </summary>
        /// <param name="sender">The component that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void OnComponentRequestReceived(object sender, MemoryRequestEventArgs e)
        {
            RequestReceived?.Invoke(this, e);
        }

        /// <summary>
        /// Handles component response generated events.
        /// </summary>
        /// <param name="sender">The component that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void OnComponentResponseGenerated(object sender, MemoryResponseEventArgs e)
        {
            ResponseGenerated?.Invoke(this, e);
        }

        /// <summary>
        /// Handles component error occurred events.
        /// </summary>
        /// <param name="sender">The component that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void OnComponentErrorOccurred(object sender, MemoryErrorEventArgs e)
        {
            OnErrorOccurred(e.ErrorMessage, e.Exception);
        }

        /// <summary>
        /// Raises the ErrorOccurred event.
        /// </summary>
        /// <param name="errorMessage">The error message</param>
        /// <param name="exception">The exception that caused the error</param>
        private void OnErrorOccurred(string errorMessage, Exception exception)
        {
            var e = new MemoryErrorEventArgs(errorMessage, exception, CurrentCycle);
            ErrorOccurred?.Invoke(this, e);
        }
    }
}

