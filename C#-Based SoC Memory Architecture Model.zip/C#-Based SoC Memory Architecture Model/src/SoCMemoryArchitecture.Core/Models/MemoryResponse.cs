using System;
using SoCMemoryArchitecture.Core.Enums;

namespace SoCMemoryArchitecture.Core.Models
{
    /// <summary>
    /// Represents a response to a memory request in the SoC memory system.
    /// </summary>
    public class MemoryResponse
    {
        /// <summary>
        /// ID of the original request
        /// </summary>
        public Guid RequestId { get; set; }

        /// <summary>
        /// Status of the memory operation
        /// </summary>
        public MemoryResponseStatus Status { get; set; }

        /// <summary>
        /// Data returned from the memory operation
        /// </summary>
        public byte[] Data { get; set; }

        /// <summary>
        /// Error message if the operation failed
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Cycle count when the response was generated
        /// </summary>
        public ulong CompletionCycle { get; set; }

        /// <summary>
        /// Timestamp when the response was created
        /// </summary>
        public DateTime Timestamp { get; set; }

        /// <summary>
        /// Additional metadata for the response
        /// </summary>
        public object Metadata { get; set; }

        /// <summary>
        /// Indicates if the operation was successful
        /// </summary>
        public bool IsSuccess => Status == MemoryResponseStatus.Success;

        /// <summary>
        /// Initializes a new instance of the MemoryResponse class.
        /// </summary>
        public MemoryResponse()
        {
            Timestamp = DateTime.UtcNow;
            Status = MemoryResponseStatus.Success;
        }

        /// <summary>
        /// Initializes a new instance of the MemoryResponse class with specified parameters.
        /// </summary>
        /// <param name="requestId">Original request ID</param>
        /// <param name="status">Response status</param>
        /// <param name="data">Response data</param>
        public MemoryResponse(Guid requestId, MemoryResponseStatus status, byte[] data = null)
            : this()
        {
            RequestId = requestId;
            Status = status;
            Data = data;
        }

        /// <summary>
        /// Creates a successful response.
        /// </summary>
        /// <param name="requestId">Original request ID</param>
        /// <param name="data">Response data</param>
        /// <returns>Successful memory response</returns>
        public static MemoryResponse Success(Guid requestId, byte[] data = null)
        {
            return new MemoryResponse(requestId, MemoryResponseStatus.Success, data);
        }

        /// <summary>
        /// Creates an error response.
        /// </summary>
        /// <param name="requestId">Original request ID</param>
        /// <param name="status">Error status</param>
        /// <param name="errorMessage">Error message</param>
        /// <returns>Error memory response</returns>
        public static MemoryResponse Error(Guid requestId, MemoryResponseStatus status, string errorMessage)
        {
            return new MemoryResponse(requestId, status)
            {
                ErrorMessage = errorMessage
            };
        }

        /// <summary>
        /// Returns a string representation of the memory response.
        /// </summary>
        /// <returns>String representation</returns>
        public override string ToString()
        {
            return $"MemoryResponse[RequestId={RequestId}, Status={Status}, Success={IsSuccess}]";
        }
    }

    /// <summary>
    /// Defines the possible status values for memory responses.
    /// </summary>
    public enum MemoryResponseStatus
    {
        /// <summary>
        /// Operation completed successfully
        /// </summary>
        Success = 0,

        /// <summary>
        /// Operation failed due to timeout
        /// </summary>
        Timeout = 1,

        /// <summary>
        /// Operation failed due to invalid address
        /// </summary>
        InvalidAddress = 2,

        /// <summary>
        /// Operation failed due to access permission
        /// </summary>
        AccessDenied = 3,

        /// <summary>
        /// Operation failed due to bus error
        /// </summary>
        BusError = 4,

        /// <summary>
        /// Operation failed due to cache coherency conflict
        /// </summary>
        CoherencyConflict = 5,

        /// <summary>
        /// Operation failed due to resource unavailability
        /// </summary>
        ResourceUnavailable = 6,

        /// <summary>
        /// Operation failed due to protocol violation
        /// </summary>
        ProtocolViolation = 7,

        /// <summary>
        /// Operation failed due to unknown error
        /// </summary>
        UnknownError = 8
    }
}

