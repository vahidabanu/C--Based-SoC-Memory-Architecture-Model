using System;
using SoCMemoryArchitecture.Core.Enums;

namespace SoCMemoryArchitecture.Core.Models
{
    /// <summary>
    /// Represents a memory request in the SoC memory system.
    /// </summary>
    public class MemoryRequest
    {
        /// <summary>
        /// Unique identifier for this request
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Memory address for the operation
        /// </summary>
        public ulong Address { get; set; }

        /// <summary>
        /// Size of the data transfer in bytes
        /// </summary>
        public uint Size { get; set; }

        /// <summary>
        /// Type of memory operation
        /// </summary>
        public MemoryRequestType Type { get; set; }

        /// <summary>
        /// Priority level for QoS support
        /// </summary>
        public Priority Priority { get; set; }

        /// <summary>
        /// Source core/agent ID
        /// </summary>
        public int SourceId { get; set; }

        /// <summary>
        /// Target core/agent ID (for multi-core systems)
        /// </summary>
        public int? TargetId { get; set; }

        /// <summary>
        /// Data payload for write operations
        /// </summary>
        public byte[] Data { get; set; }

        /// <summary>
        /// Timestamp when the request was created
        /// </summary>
        public DateTime Timestamp { get; set; }

        /// <summary>
        /// Cycle count when the request was issued
        /// </summary>
        public ulong IssueCycle { get; set; }

        /// <summary>
        /// Cycle count when the request was completed
        /// </summary>
        public ulong? CompletionCycle { get; set; }

        /// <summary>
        /// Additional metadata for the request
        /// </summary>
        public object Metadata { get; set; }

        /// <summary>
        /// Indicates if this is a cacheable request
        /// </summary>
        public bool Cacheable { get; set; } = true;

        /// <summary>
        /// Indicates if this request requires ordering guarantees
        /// </summary>
        public bool Ordered { get; set; } = false;

        /// <summary>
        /// Indicates if this is an atomic operation
        /// </summary>
        public bool Atomic { get; set; } = false;

        /// <summary>
        /// Initializes a new instance of the MemoryRequest class.
        /// </summary>
        public MemoryRequest()
        {
            Id = Guid.NewGuid();
            Timestamp = DateTime.UtcNow;
            Priority = Priority.Normal;
            Type = MemoryRequestType.Read;
            Cacheable = true;
        }

        /// <summary>
        /// Initializes a new instance of the MemoryRequest class with specified parameters.
        /// </summary>
        /// <param name="address">Memory address</param>
        /// <param name="size">Data size in bytes</param>
        /// <param name="type">Request type</param>
        /// <param name="priority">Priority level</param>
        public MemoryRequest(ulong address, uint size, MemoryRequestType type, Priority priority = Priority.Normal)
            : this()
        {
            Address = address;
            Size = size;
            Type = type;
            Priority = priority;
        }

        /// <summary>
        /// Gets the latency of this request in cycles.
        /// </summary>
        /// <returns>Latency in cycles, or null if not completed</returns>
        public ulong? GetLatency()
        {
            return CompletionCycle.HasValue ? CompletionCycle.Value - IssueCycle : null;
        }

        /// <summary>
        /// Creates a response for this request.
        /// </summary>
        /// <param name="data">Response data</param>
        /// <param name="status">Response status</param>
        /// <returns>Memory response</returns>
        public MemoryResponse CreateResponse(byte[] data = null, MemoryResponseStatus status = MemoryResponseStatus.Success)
        {
            return new MemoryResponse
            {
                RequestId = Id,
                Data = data,
                Status = status,
                CompletionCycle = CompletionCycle ?? 0
            };
        }

        /// <summary>
        /// Returns a string representation of the memory request.
        /// </summary>
        /// <returns>String representation</returns>
        public override string ToString()
        {
            return $"MemoryRequest[Id={Id}, Address=0x{Address:X}, Size={Size}, Type={Type}, Priority={Priority}, Source={SourceId}]";
        }
    }
}

