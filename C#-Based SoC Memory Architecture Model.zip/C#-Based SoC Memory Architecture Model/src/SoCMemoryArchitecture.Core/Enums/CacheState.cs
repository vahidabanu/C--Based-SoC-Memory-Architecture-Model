namespace SoCMemoryArchitecture.Core.Enums
{
    /// <summary>
    /// Defines cache line states for MESI/MOESI cache coherency protocols.
    /// </summary>
    public enum CacheState
    {
        /// <summary>
        /// Invalid - cache line is not valid
        /// </summary>
        Invalid = 0,

        /// <summary>
        /// Shared - cache line is shared across multiple caches
        /// </summary>
        Shared = 1,

        /// <summary>
        /// Exclusive - cache line is exclusively owned by this cache
        /// </summary>
        Exclusive = 2,

        /// <summary>
        /// Modified - cache line has been modified and is dirty
        /// </summary>
        Modified = 3,

        /// <summary>
        /// Owned - cache line is owned by this cache but may be shared (MOESI)
        /// </summary>
        Owned = 4,

        /// <summary>
        /// Forward - cache line is being forwarded to another cache
        /// </summary>
        Forward = 5
    }
}

