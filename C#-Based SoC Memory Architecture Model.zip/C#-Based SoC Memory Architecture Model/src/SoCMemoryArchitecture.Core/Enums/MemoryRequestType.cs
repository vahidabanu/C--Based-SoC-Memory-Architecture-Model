namespace SoCMemoryArchitecture.Core.Enums
{
    /// <summary>
    /// Defines the types of memory requests that can be processed by the memory system.
    /// </summary>
    public enum MemoryRequestType
    {
        /// <summary>
        /// Read operation from memory
        /// </summary>
        Read = 0,

        /// <summary>
        /// Write operation to memory
        /// </summary>
        Write = 1,

        /// <summary>
        /// Read-modify-write atomic operation
        /// </summary>
        ReadModifyWrite = 2,

        /// <summary>
        /// Cache line invalidation
        /// </summary>
        Invalidate = 3,

        /// <summary>
        /// Cache line flush to memory
        /// </summary>
        Flush = 4,

        /// <summary>
        /// Prefetch operation for performance optimization
        /// </summary>
        Prefetch = 5,

        /// <summary>
        /// Memory barrier for ordering guarantees
        /// </summary>
        MemoryBarrier = 6,

        /// <summary>
        /// Cache coherency snoop request
        /// </summary>
        Snoop = 7,

        /// <summary>
        /// Debug access for testing and verification
        /// </summary>
        Debug = 8
    }
}

