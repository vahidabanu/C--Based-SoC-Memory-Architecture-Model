namespace SoCMemoryArchitecture.Core.Enums
{
    /// <summary>
    /// Defines priority levels for memory requests to support Quality of Service (QoS).
    /// </summary>
    public enum Priority
    {
        /// <summary>
        /// Lowest priority - background tasks
        /// </summary>
        Low = 0,

        /// <summary>
        /// Normal priority - standard operations
        /// </summary>
        Normal = 1,

        /// <summary>
        /// High priority - time-sensitive operations
        /// </summary>
        High = 2,

        /// <summary>
        /// Critical priority - real-time operations
        /// </summary>
        Critical = 3,

        /// <summary>
        /// Emergency priority - system-critical operations
        /// </summary>
        Emergency = 4
    }
}

