namespace SoCMemoryArchitecture.AXI.Enums
{
    /// <summary>
    /// Defines the AXI burst types for memory transfers.
    /// </summary>
    public enum AxiBurstType
    {
        /// <summary>
        /// Fixed burst - same address for all transfers
        /// </summary>
        Fixed = 0,

        /// <summary>
        /// Incrementing burst - address increments for each transfer
        /// </summary>
        Increment = 1,

        /// <summary>
        /// Wrapping burst - address wraps around within the burst boundary
        /// </summary>
        Wrap = 2
    }
}

