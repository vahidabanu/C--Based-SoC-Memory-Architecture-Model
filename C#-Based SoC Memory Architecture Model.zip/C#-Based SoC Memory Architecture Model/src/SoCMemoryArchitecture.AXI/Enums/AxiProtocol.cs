namespace SoCMemoryArchitecture.AXI.Enums
{
    /// <summary>
    /// Defines the AXI protocol versions and variants supported by the system.
    /// </summary>
    public enum AxiProtocol
    {
        /// <summary>
        /// AXI3 protocol (AMBA 3.0)
        /// </summary>
        AXI3 = 0,

        /// <summary>
        /// AXI4 protocol (AMBA 4.0)
        /// </summary>
        AXI4 = 1,

        /// <summary>
        /// AXI4-Lite protocol (simplified AXI4)
        /// </summary>
        AXI4Lite = 2,

        /// <summary>
        /// AXI4-Stream protocol (streaming data)
        /// </summary>
        AXI4Stream = 3,

        /// <summary>
        /// AXI5 protocol (AMBA 5.0)
        /// </summary>
        AXI5 = 4,

        /// <summary>
        /// AHB protocol (AMBA 2.0)
        /// </summary>
        AHB = 5,

        /// <summary>
        /// APB protocol (AMBA 2.0)
        /// </summary>
        APB = 6
    }
}

