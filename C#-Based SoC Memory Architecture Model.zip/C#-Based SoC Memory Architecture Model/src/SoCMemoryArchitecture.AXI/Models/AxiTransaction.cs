using System;
using SoCMemoryArchitecture.AXI.Enums;
using SoCMemoryArchitecture.Core.Enums;

namespace SoCMemoryArchitecture.AXI.Models
{
    /// <summary>
    /// Represents an AXI bus transaction with all necessary signals and properties.
    /// </summary>
    public class AxiTransaction
    {
        /// <summary>
        /// Unique identifier for this transaction
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// AXI protocol version being used
        /// </summary>
        public AxiProtocol Protocol { get; set; }

        /// <summary>
        /// Transaction type (read/write)
        /// </summary>
        public MemoryRequestType TransactionType { get; set; }

        /// <summary>
        /// Master ID that initiated the transaction
        /// </summary>
        public int MasterId { get; set; }

        /// <summary>
        /// Slave ID that is the target of the transaction
        /// </summary>
        public int SlaveId { get; set; }

        /// <summary>
        /// Transaction address
        /// </summary>
        public ulong Address { get; set; }

        /// <summary>
        /// Burst type for this transaction
        /// </summary>
        public AxiBurstType BurstType { get; set; }

        /// <summary>
        /// Burst length (number of transfers)
        /// </summary>
        public uint BurstLength { get; set; }

        /// <summary>
        /// Burst size (size of each transfer in bytes)
        /// </summary>
        public uint BurstSize { get; set; }

        /// <summary>
        /// Quality of Service level
        /// </summary>
        public uint QoS { get; set; }

        /// <summary>
        /// Transaction ID for out-of-order completion
        /// </summary>
        public uint TransactionId { get; set; }

        /// <summary>
        /// User-defined signals
        /// </summary>
        public uint UserSignals { get; set; }

        /// <summary>
        /// Data payload for write transactions
        /// </summary>
        public byte[] Data { get; set; }

        /// <summary>
        /// Write strobes for write transactions
        /// </summary>
        public byte[] WriteStrobes { get; set; }

        /// <summary>
        /// Response status
        /// </summary>
        public AxiResponseStatus ResponseStatus { get; set; }

        /// <summary>
        /// Cycle when the transaction was initiated
        /// </summary>
        public ulong StartCycle { get; set; }

        /// <summary>
        /// Cycle when the transaction completed
        /// </summary>
        public ulong? EndCycle { get; set; }

        /// <summary>
        /// Indicates if this transaction is cacheable
        /// </summary>
        public bool Cacheable { get; set; } = true;

        /// <summary>
        /// Indicates if this transaction requires ordering guarantees
        /// </summary>
        public bool Ordered { get; set; } = false;

        /// <summary>
        /// Indicates if this transaction is exclusive (for atomic operations)
        /// </summary>
        public bool Exclusive { get; set; } = false;

        /// <summary>
        /// Indicates if this transaction is locked
        /// </summary>
        public bool Locked { get; set; } = false;

        /// <summary>
        /// Initializes a new instance of the AxiTransaction class.
        /// </summary>
        public AxiTransaction()
        {
            Id = Guid.NewGuid();
            Protocol = AxiProtocol.AXI4;
            TransactionType = MemoryRequestType.Read;
            BurstType = AxiBurstType.Increment;
            BurstLength = 1;
            BurstSize = 4;
            QoS = 0;
            ResponseStatus = AxiResponseStatus.OKAY;
            Cacheable = true;
        }

        /// <summary>
        /// Initializes a new instance of the AxiTransaction class with specified parameters.
        /// </summary>
        /// <param name="protocol">AXI protocol version</param>
        /// <param name="transactionType">Transaction type</param>
        /// <param name="address">Transaction address</param>
        /// <param name="burstLength">Burst length</param>
        /// <param name="burstSize">Burst size</param>
        public AxiTransaction(AxiProtocol protocol, MemoryRequestType transactionType, ulong address, uint burstLength = 1, uint burstSize = 4)
            : this()
        {
            Protocol = protocol;
            TransactionType = transactionType;
            Address = address;
            BurstLength = burstLength;
            BurstSize = burstSize;
        }

        /// <summary>
        /// Gets the total number of bytes transferred in this transaction.
        /// </summary>
        /// <returns>Total bytes transferred</returns>
        public ulong GetTotalBytes()
        {
            return (ulong)BurstLength * BurstSize;
        }

        /// <summary>
        /// Gets the latency of this transaction in cycles.
        /// </summary>
        /// <returns>Latency in cycles, or null if not completed</returns>
        public ulong? GetLatency()
        {
            return EndCycle.HasValue ? EndCycle.Value - StartCycle : null;
        }

        /// <summary>
        /// Calculates the address for a specific beat in the burst.
        /// </summary>
        /// <param name="beatIndex">Index of the beat (0-based)</param>
        /// <returns>Address for the specified beat</returns>
        public ulong GetBeatAddress(uint beatIndex)
        {
            if (beatIndex >= BurstLength)
                throw new ArgumentOutOfRangeException(nameof(beatIndex), "Beat index exceeds burst length");

            switch (BurstType)
            {
                case AxiBurstType.Fixed:
                    return Address;

                case AxiBurstType.Increment:
                    return Address + (beatIndex * BurstSize);

                case AxiBurstType.Wrap:
                    var burstBoundary = BurstLength * BurstSize;
                    var offset = (beatIndex * BurstSize) % burstBoundary;
                    return (Address & ~(burstBoundary - 1)) + offset;

                default:
                    throw new NotSupportedException($"Burst type {BurstType} is not supported");
            }
        }

        /// <summary>
        /// Returns a string representation of the AXI transaction.
        /// </summary>
        /// <returns>String representation</returns>
        public override string ToString()
        {
            return $"AxiTransaction[Id={Id}, Protocol={Protocol}, Type={TransactionType}, Address=0x{Address:X}, Burst={BurstType}x{BurstLength}x{BurstSize}]";
        }
    }

    /// <summary>
    /// Defines the AXI response status values.
    /// </summary>
    public enum AxiResponseStatus
    {
        /// <summary>
        /// Normal successful response
        /// </summary>
        OKAY = 0,

        /// <summary>
        /// Exclusive access failed
        /// </summary>
        EXOKAY = 1,

        /// <summary>
        /// Slave error
        /// </summary>
        SLVERR = 2,

        /// <summary>
        /// Decode error
        /// </summary>
        DECERR = 3
    }
}

