using System;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SoCMemoryArchitecture.Core.Models;
using SoCMemoryArchitecture.Core.Enums;
using SoCMemoryArchitecture.Cache.Models;
using SoCMemoryArchitecture.AXI.Models;
using SoCMemoryArchitecture.AXI.Enums;
using SoCMemoryArchitecture.DRAM.Enums;

namespace SoCMemoryArchitecture.Examples
{
    /// <summary>
    /// Main program demonstrating the SoC Memory Architecture capabilities.
    /// </summary>
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== SoC Memory Architecture Model ===");
            Console.WriteLine("Comprehensive C#-Based SoC Memory Subsystem Simulation");
            Console.WriteLine("=====================================\n");

            // Setup dependency injection
            var services = new ServiceCollection();
            ConfigureServices(services);
            var serviceProvider = services.BuildServiceProvider();

            var logger = serviceProvider.GetService<ILogger<Program>>();

            try
            {
                // Run different examples
                await RunBasicMemorySystemExample(logger);
                await RunAXIProtocolExample(logger);
                await RunCacheHierarchyExample(logger);
                await RunDRAMTimingExample(logger);
                await RunPerformanceAnalysisExample(logger);
                await RunMultiCoreExample(logger);

                Console.WriteLine("\n=== All Examples Completed Successfully ===");
            }
            catch (Exception ex)
            {
                logger?.LogError(ex, "Error running examples");
                Console.WriteLine($"Error: {ex.Message}");
            }

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }

        /// <summary>
        /// Configures the dependency injection services.
        /// </summary>
        /// <param name="services">Service collection</param>
        private static void ConfigureServices(IServiceCollection services)
        {
            services.AddLogging(builder =>
            {
                builder.AddConsole();
                builder.SetMinimumLevel(LogLevel.Information);
            });
        }

        /// <summary>
        /// Demonstrates basic memory system setup and operation.
        /// </summary>
        /// <param name="logger">Logger instance</param>
        private static async Task RunBasicMemorySystemExample(ILogger logger)
        {
            Console.WriteLine("1. Basic Memory System Example");
            Console.WriteLine("==============================");

            // Create memory system
            var memorySystem = new MemorySystem("Basic SoC Memory System", logger);

            // Initialize the system
            await memorySystem.InitializeAsync();

            // Create and process memory requests
            var requests = new[]
            {
                new MemoryRequest(0x1000, 64, MemoryRequestType.Read, Priority.Normal),
                new MemoryRequest(0x2000, 128, MemoryRequestType.Write, Priority.High),
                new MemoryRequest(0x3000, 32, MemoryRequestType.Read, Priority.Low)
            };

            foreach (var request in requests)
            {
                request.SourceId = 1; // CPU core 1
                var response = await memorySystem.ProcessRequestAsync(request);
                
                Console.WriteLine($"Request {request.Id}: {request.Type} at 0x{request.Address:X} -> {response.Status}");
            }

            // Get system statistics
            var stats = memorySystem.GetStatistics();
            Console.WriteLine($"\nSystem Statistics:");
            Console.WriteLine($"- Total Requests: {stats.TotalRequests}");
            Console.WriteLine($"- Success Rate: {stats.SuccessRate:F2}%");
            Console.WriteLine($"- Average Latency: {stats.AverageLatency:F2} cycles");
            Console.WriteLine($"- Power Consumption: {memorySystem.PowerConsumption:F2} mW");

            Console.WriteLine();
        }

        /// <summary>
        /// Demonstrates AXI protocol implementation and transactions.
        /// </summary>
        /// <param name="logger">Logger instance</param>
        private static async Task RunAXIProtocolExample(ILogger logger)
        {
            Console.WriteLine("2. AXI Protocol Example");
            Console.WriteLine("=======================");

            // Create AXI transactions
            var transactions = new[]
            {
                new AxiTransaction(AxiProtocol.AXI4, MemoryRequestType.Read, 0x1000, 4, 64),
                new AxiTransaction(AxiProtocol.AXI4, MemoryRequestType.Write, 0x2000, 8, 32),
                new AxiTransaction(AxiProtocol.AXI4, MemoryRequestType.Read, 0x3000, 1, 128)
            };

            foreach (var transaction in transactions)
            {
                transaction.MasterId = 1;
                transaction.SlaveId = 0;
                transaction.QoS = 2;
                transaction.StartCycle = 100;

                Console.WriteLine($"AXI Transaction: {transaction}");
                Console.WriteLine($"  - Total Bytes: {transaction.GetTotalBytes()}");
                Console.WriteLine($"  - Burst Type: {transaction.BurstType}");
                Console.WriteLine($"  - Protocol: {transaction.Protocol}");

                // Simulate transaction completion
                transaction.EndCycle = transaction.StartCycle + 20;
                var latency = transaction.GetLatency();
                Console.WriteLine($"  - Latency: {latency} cycles");
            }

            Console.WriteLine();
        }

        /// <summary>
        /// Demonstrates cache hierarchy configuration and operation.
        /// </summary>
        /// <param name="logger">Logger instance</param>
        private static async Task RunCacheHierarchyExample(ILogger logger)
        {
            Console.WriteLine("3. Cache Hierarchy Example");
            Console.WriteLine("==========================");

            // Configure L1 cache
            var l1Config = new CacheConfiguration(32 * 1024, 64, 4) // 32KB, 64-byte lines, 4-way
            {
                ReplacementPolicy = ReplacementPolicy.LRU,
                WritePolicy = WritePolicy.WriteBack,
                WriteAllocationPolicy = WriteAllocationPolicy.WriteAllocate,
                CoherencyProtocol = CoherencyProtocol.MESI,
                HitLatency = 1,
                MissLatency = 10,
                PowerPerAccess = 0.5,
                StaticPower = 5.0
            };

            // Configure L2 cache
            var l2Config = new CacheConfiguration(256 * 1024, 64, 8) // 256KB, 64-byte lines, 8-way
            {
                ReplacementPolicy = ReplacementPolicy.PLRU,
                WritePolicy = WritePolicy.WriteBack,
                WriteAllocationPolicy = WriteAllocationPolicy.WriteAllocate,
                CoherencyProtocol = CoherencyProtocol.MOESI,
                HitLatency = 5,
                MissLatency = 50,
                PowerPerAccess = 2.0,
                StaticPower = 20.0
            };

            Console.WriteLine($"L1 Cache Configuration:");
            Console.WriteLine($"  - Size: {l1Config.Size / 1024} KB");
            Console.WriteLine($"  - Line Size: {l1Config.LineSize} bytes");
            Console.WriteLine($"  - Associativity: {l1Config.Associativity}-way");
            Console.WriteLine($"  - Sets: {l1Config.Sets}");
            Console.WriteLine($"  - Hit Latency: {l1Config.HitLatency} cycles");
            Console.WriteLine($"  - Power per Access: {l1Config.PowerPerAccess} mW");

            Console.WriteLine($"\nL2 Cache Configuration:");
            Console.WriteLine($"  - Size: {l2Config.Size / 1024} KB");
            Console.WriteLine($"  - Line Size: {l2Config.LineSize} bytes");
            Console.WriteLine($"  - Associativity: {l2Config.Associativity}-way");
            Console.WriteLine($"  - Sets: {l2Config.Sets}");
            Console.WriteLine($"  - Hit Latency: {l2Config.HitLatency} cycles");
            Console.WriteLine($"  - Power per Access: {l2Config.PowerPerAccess} mW");

            // Validate configurations
            Console.WriteLine($"\nL1 Cache Valid: {l1Config.Validate()}");
            Console.WriteLine($"L2 Cache Valid: {l2Config.Validate()}");

            Console.WriteLine();
        }

        /// <summary>
        /// Demonstrates DRAM timing models and operations.
        /// </summary>
        /// <param name="logger">Logger instance</param>
        private static async Task RunDRAMTimingExample(ILogger logger)
        {
            Console.WriteLine("4. DRAM Timing Example");
            Console.WriteLine("======================");

            // Simulate different DRAM types
            var dramTypes = new[] { DramType.DDR4, DramType.DDR5, DramType.LPDDR4 };

            foreach (var dramType in dramTypes)
            {
                Console.WriteLine($"\n{dramType} Configuration:");
                
                // Simulate DRAM parameters based on type
                uint dataRate = dramType switch
                {
                    DramType.DDR4 => 3200,
                    DramType.DDR5 => 6400,
                    DramType.LPDDR4 => 4266,
                    _ => 1600
                };

                uint capacity = 8 * 1024 * 1024 * 1024UL; // 8GB
                uint channels = 2;
                uint ranksPerChannel = 2;

                Console.WriteLine($"  - Data Rate: {dataRate} MT/s");
                Console.WriteLine($"  - Capacity: {capacity / (1024 * 1024 * 1024)} GB");
                Console.WriteLine($"  - Channels: {channels}");
                Console.WriteLine($"  - Ranks per Channel: {ranksPerChannel}");

                // Calculate theoretical bandwidth
                double bandwidth = (dataRate * channels * 8) / 1000.0; // GB/s
                Console.WriteLine($"  - Theoretical Bandwidth: {bandwidth:F1} GB/s");

                // Simulate DRAM commands
                var commands = new[] { DramCommand.ACT, DramCommand.READ, DramCommand.WRITE, DramCommand.PRE };
                foreach (var command in commands)
                {
                    Console.WriteLine($"  - Command: {command}");
                }
            }

            Console.WriteLine();
        }

        /// <summary>
        /// Demonstrates performance analysis capabilities.
        /// </summary>
        /// <param name="logger">Logger instance</param>
        private static async Task RunPerformanceAnalysisExample(ILogger logger)
        {
            Console.WriteLine("5. Performance Analysis Example");
            Console.WriteLine("===============================");

            // Simulate performance metrics
            var metrics = new
            {
                L1HitRate = 95.2,
                L2HitRate = 85.7,
                AverageMemoryLatency = 45.3,
                MemoryBandwidth = 25.6,
                PowerEfficiency = 0.85
            };

            Console.WriteLine("Performance Metrics:");
            Console.WriteLine($"  - L1 Cache Hit Rate: {metrics.L1HitRate:F1}%");
            Console.WriteLine($"  - L2 Cache Hit Rate: {metrics.L2HitRate:F1}%");
            Console.WriteLine($"  - Average Memory Latency: {metrics.AverageMemoryLatency:F1} cycles");
            Console.WriteLine($"  - Memory Bandwidth: {metrics.MemoryBandwidth:F1} GB/s");
            Console.WriteLine($"  - Power Efficiency: {metrics.PowerEfficiency:P0}");

            // Simulate workload analysis
            var workloads = new[]
            {
                new { Name = "CPU-Intensive", L1HitRate = 92.1, L2HitRate = 78.3, Bandwidth = 18.2 },
                new { Name = "Memory-Intensive", L1HitRate = 65.4, L2HitRate = 45.2, Bandwidth = 32.8 },
                new { Name = "Mixed Workload", L1HitRate = 88.7, L2HitRate = 72.1, Bandwidth = 24.5 }
            };

            Console.WriteLine("\nWorkload Analysis:");
            foreach (var workload in workloads)
            {
                Console.WriteLine($"  {workload.Name}:");
                Console.WriteLine($"    - L1 Hit Rate: {workload.L1HitRate:F1}%");
                Console.WriteLine($"    - L2 Hit Rate: {workload.L2HitRate:F1}%");
                Console.WriteLine($"    - Bandwidth: {workload.Bandwidth:F1} GB/s");
            }

            Console.WriteLine();
        }

        /// <summary>
        /// Demonstrates multi-core cache coherency.
        /// </summary>
        /// <param name="logger">Logger instance</param>
        private static async Task RunMultiCoreExample(ILogger logger)
        {
            Console.WriteLine("6. Multi-Core Cache Coherency Example");
            Console.WriteLine("=====================================");

            // Simulate multi-core system
            var cores = 4;
            var sharedAddress = 0x1000UL;

            Console.WriteLine($"Multi-Core System ({cores} cores):");

            // Simulate cache coherency scenarios
            for (int coreId = 0; coreId < cores; coreId++)
            {
                var request = new MemoryRequest(sharedAddress, 64, MemoryRequestType.Read, Priority.Normal)
                {
                    SourceId = coreId,
                    Cacheable = true
                };

                Console.WriteLine($"  Core {coreId}: Read request to 0x{sharedAddress:X}");
            }

            // Simulate write from one core
            var writeRequest = new MemoryRequest(sharedAddress, 64, MemoryRequestType.Write, Priority.High)
            {
                SourceId = 1,
                Cacheable = true
            };

            Console.WriteLine($"  Core 1: Write request to 0x{sharedAddress:X} (triggers coherency)");

            // Simulate coherency protocol actions
            var coherencyActions = new[]
            {
                "Invalidate other caches",
                "Update cache state to Modified",
                "Send acknowledgment to requester"
            };

            Console.WriteLine("  Coherency Actions:");
            foreach (var action in coherencyActions)
            {
                Console.WriteLine($"    - {action}");
            }

            Console.WriteLine();
        }
    }
}

